import { TMenuRoutine } from "@/types/global/menu.type";
import { atom } from "jotai";

export const menuOpenAtom = atom<boolean>(false);
export const menuRoutinesAtom = atom<TMenuRoutine[]>([
    {
        code: '00',
        isOpen: true,
        authorized: false,
        description: 'Home',
        icon: 'FiGrid',
        link: '',
        padding: 'px-2',
        subMenu: [
            {
                code: '001',
                isOpen: true,
                subMenu: [],
                description: 'Dashboard',
                icon: '',
                link: '/dashboard',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },     
        ],
    },
    {
        code: '1',
        isOpen: true,
        authorized: false,
        description: 'Cadastro',
        icon: 'FiGrid',
        link: '',
        padding: 'px-2',
        subMenu: [
            {
                code: 'A11',
                isOpen: true,
                subMenu: [],
                description: 'Usuários',
                icon: '',
                link: 'master-data/users',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },     
            {
                code: 'A12',
                isOpen: true,
                subMenu: [],
                description: 'Clientes',
                icon: '',
                link: 'master-data/customers',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A13',
                isOpen: true,
                subMenu: [],
                description: 'Profissionais',
                icon: '',
                link: 'master-data/professionals',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A14',
                isOpen: true,
                subMenu: [],
                description: 'Módulos de Serviços',
                icon: '',
                link: 'master-data/service-modules',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A15',
                isOpen: true,
                subMenu: [],
                description: 'Programas',
                icon: '',
                link: 'master-data/plas',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A16',
                isOpen: true,
                subMenu: [],
                description: 'Procedimentos',
                icon: '',
                link: 'master-data/procedures',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A17',
                isOpen: true,
                subMenu: [],
                description: 'Faturamento',
                icon: '',
                link: 'master-data/billings',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A18',
                isOpen: true,
                subMenu: [],
                description: 'Vendedores',
                icon: '',
                link: 'master-data/sellers',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A19',
                isOpen: true,
                subMenu: [],
                description: 'Representantes',
                icon: '',
                link: 'master-data/sellers-representative',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'A20',
                isOpen: true,
                subMenu: [],
                description: 'Comissões',
                icon: '',
                link: 'master-data/commissions',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },       
            {
                code: 'A21',
                isOpen: true,
                subMenu: [],
                description: 'Rede Credenciada',
                icon: '',
                link: 'master-data/accredited-network',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },                        
            {
                code: 'A23',
                isOpen: true,
                subMenu: [],
                description: 'Tabelas Genérica',
                icon: '',
                link: 'master-data/generic-tables',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },            
            {
                code: 'A24',
                isOpen: true,
                subMenu: [],
                description: 'Fornecedores',
                icon: '',
                link: 'master-data/suppliers',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },                       
        ],
    },
    {
        code: '2',
        isOpen: true,
        authorized: false,
        subMenu: [
            {
                code: 'B22',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Presencial',
                // icon: 'FaMoneyBillTrendUp',
                icon: '',
                link: 'services/in-person',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'B23',
                isOpen: false,
                authorized: false,
                subMenu: [
                    {
                        code: 'B24',
                        isOpen: false,
                        authorized: false,
                        subMenu: [],
                        description: 'Encaminhamentos',
                        // icon: 'PiMoneyFill',
                        icon: '',
                        link: 'services/forwardings',
                        padding: 'px-4',
                        permissions: {
                            create: false,
                            update: false,
                            read: false,
                            delete: false
                        }
                    },
                    {
                        code: 'B25',
                        isOpen: false,
                        authorized: false,
                        subMenu: [],
                        description: 'Agendamentos',
                        // icon: 'PiMoneyFill',
                        icon: '',
                        link: 'services/appointments',
                        padding: 'px-4',
                        permissions: {
                            create: false,
                            update: false,
                            read: false,
                            delete: false
                        }
                    }
                ],
                description: 'Telemedicina',
                // icon: 'PiMoneyFill',
                icon: '',
                link: '',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'B26',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Historico',
                // icon: 'PiMoneyFill',
                icon: '',
                link: 'services/historics',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            }
        ],
        description: 'Atendimentos',
        icon: 'MdChat',
        link: '',
        padding: 'px-2'
    },
    {
        code: '3',
        isOpen: true,
        authorized: false,
        subMenu: [
            {
                code: 'C32',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Contas a Receber',
                // icon: 'FaMoneyBillTrendUp',
                icon: '',
                link: 'financial/accounts-receivable',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'C33',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Contas a Pagar',
                // icon: 'PiMoneyFill',
                icon: '',
                link: 'financial/accounts-payable',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            }
        ],
        description: 'Financeiro',
        icon: 'BsCashCoin',
        link: '',
        padding: 'px-2'
    },
    {
        code: '4',
        isOpen: true,
        authorized: false,
        subMenu: [
            {
                code: 'D02',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Painel do Gestor',
                icon: '',
                link: 'management/b2b-panel',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'D03',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Saúde Ocupacional',
                icon: '',
                link: 'management/occupational-management',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'D04',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Visão Executiva',
                icon: '',
                link: 'dashboard/executivo/iso',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
            {
                code: 'D05',
                isOpen: false,
                authorized: false,
                subMenu: [],
                description: 'Painel SST',
                icon: '',
                link: 'dashboard/executivo/sst',
                padding: 'px-4',
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
        ],
        description: 'Gestão',
        icon: 'BsCashCoin',
        link: '',
        padding: 'px-2'
    },
    {
        code: '5',
        isOpen: true,
        authorized: false,
        description: 'Configurações',
        icon: 'MdSettings',
        link: '',
        padding: 'px-2',
        subMenu: [
            {
                code: 'E01',
                isOpen: true,
                subMenu: [],
                description: 'Perfis de Permissão',
                icon: '',
                link: 'settings/permission-profiles',
                padding: 'px-4',
                authorized: false,
                permissions: {
                    create: false,
                    update: false,
                    read: false,
                    delete: false
                }
            },
        ],
    },
    {
        code: '0',
        isOpen: true,
        authorized: true,
        description: 'Sair',
        icon: '',
        link: '/',
        padding: 'px-2',
        subMenu: []
    }
]);