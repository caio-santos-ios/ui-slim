export type TContract = {
    
}