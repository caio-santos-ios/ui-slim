import { Loading } from "@/components/Global/Loading";
import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Pasbem | Gestão Ocupacional",
  description: "Gestão Ocupacional",
};

export default function OccupationalManagementLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <div className="dashboard-wrapper">
      <Loading />
      {children}
    </div>
  );
}
