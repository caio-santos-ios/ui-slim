"use client";

import { userLoggerAtom } from "@/jotai/auth/auth.jotai";
import { paginationAtom } from "@/jotai/global/pagination.jotai";
import { loadingAtom } from "@/jotai/global/loading.jotai";
import { api } from "@/service/api.service";
import { configApi, resolveResponse } from "@/service/config.service";
import { useAtom } from "jotai";
import { useEffect, useState, useMemo, useCallback } from "react";
import { useForm } from "react-hook-form";
import { Autorization } from "@/components/Global/Autorization";
import { Header } from "@/components/Global/Header";
import { SideMenu } from "@/components/Global/SideMenu";
import { SlimContainer } from "@/components/Global/SlimContainer";
import DataTable from "@/components/Global/Table";
import { NotData } from "@/components/Global/NotData";
import { ModalDelete } from "@/components/Global/ModalDelete";
import { maskDate } from "@/utils/mask.util";
import { convertNumberMoney } from "@/utils/convert.util";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/Global/Accordion/AccordionContent";
import { IoSearch } from "react-icons/io5";
import { MdFilterAlt, MdFilterAltOff, MdOutlineAttachFile, MdOutlineReceipt } from "react-icons/md";
import { FiDownload, FiUsers } from "react-icons/fi";
import { ModalB2BMassMovement } from "@/components/B2BPanel/Modal/ModalMassMovement";
import { ModalB2BInvoice, ModalB2BAttachment } from "@/components/B2BPanel/Modal/ModalInvoiceAndAttachment";
import { IconView } from "@/components/Global/IconView";
import { IconEdit } from "@/components/Global/IconEdit";
import { IconDelete } from "@/components/Global/IconDelete";

// ─── Constantes fora do componente ───────────────────────────────────────────
type TTab = "movements" | "invoices" | "attachments";

const URI_MAP: Record<TTab, string> = {
  movements:   "b2b-mass-movements",
  invoices:    "b2b-invoices",
  attachments: "attachments",
};

const MONTHS_SHORT: string[] = ["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"];
const MONTHS: string[] = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];

const movementColumns = [
  { key: "name",          title: "Beneficiário" },
  { key: "cpf",           title: "CPF" },
  { key: "planName",      title: "Programa" },
  { key: "active",        title: "Status" },
  { key: "role",          title: "Função" },
  { key: "department",    title: "Departamento" },
  { key: "effectiveDate", title: "Data de Vigência" },
];

const invoiceColumns = [
  { key: "referenceMonth",   title: "Mês/Ano" },
  { key: "beneficiaryCount", title: "Beneficiários" },
  { key: "totalAmount",      title: "Valor Total" },
  { key: "status",           title: "Status" },
  { key: "dueDate",          title: "Vencimento" },
  { key: "closingDate",      title: "Data de Corte" },
];

const attachmentColumns = [
  { key: "description", title: "Nome" },
  { key: "createdAt",   title: "Data" },
];

// ─── Filtro ───────────────────────────────────────────────────────────────────
type TFilter = {
  search:           string;
  "gte$createdAt":  string;
  "lte$createdAt":  string;
  status:           string;
  type:             string;
  customerId:       string;
  department:       string;
  period:           string;
  referenceMonth:   string;
  referenceYear:    string;
};

const ResetFilter: TFilter = {
  search:           "",
  "gte$createdAt":  "",
  "lte$createdAt":  "",
  status:           "",
  type:             "",
  customerId:       "",
  department:       "",
  period:           "",
  referenceMonth:   "",
  referenceYear:    "",
};

// ─── Badge de status ──────────────────────────────────────────────────────────
const StatusBadge = ({ value }: { value: any }) => {
  const map: Record<string, string> = {
    Ativo:       "bg-green-100 text-green-800 border-green-200",
    Inativo:     "bg-red-100 text-red-800 border-red-200",
    Pendente:    "bg-yellow-100 text-yellow-800 border-yellow-200",
    Processado:  "bg-green-100 text-green-800 border-green-200",
    Erro:        "bg-red-100 text-red-800 border-red-200",
    Aberta:      "bg-blue-100 text-blue-800 border-blue-200",
    Fechada:     "bg-gray-100 text-gray-700 border-gray-200",
    Paga:        "bg-green-100 text-green-800 border-green-200",
    Cancelada:   "bg-red-100 text-red-800 border-red-200",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold border ${map[value] ?? "bg-gray-100 text-gray-700 border-gray-200"}`}>
      {value}
    </span>
  );
};

// ═══════════════════════════════════════════════════════════════════════════
// GRÁFICOS
// ═══════════════════════════════════════════════════════════════════════════

function ColunasAtivosInativos({ ativos, inativos }: { ativos: number; inativos: number }) {
  const total = ativos + inativos || 1;
  const maxH = 160;
  const hAtivo   = Math.round((ativos   / total) * maxH);
  const hInativo = Math.round((inativos / total) * maxH);
  return (
    <div className="rounded-2xl p-5" style={{ background: "var(--surface-card)", border: "1px solid var(--surface-border)" }}>
      <p className="text-sm font-bold text-[var(--primary-color)] mb-4">Beneficiários Ativos / Inativos</p>
      <div className="flex items-end justify-center gap-10" style={{ height: 200 }}>
        <div className="flex flex-col items-center gap-2">
          <span className="text-lg font-black text-green-700">{ativos}</span>
          <div
            className="w-20 rounded-t-xl transition-all duration-700"
            style={{ height: `${hAtivo || 6}px`, background: "linear-gradient(180deg, #22c55e, #16a34a)", minHeight: 6 }}
          />
          <span className="text-sm font-semibold text-[var(--text-muted)]">Ativos</span>
        </div>
        <div className="flex flex-col items-center gap-2">
          <span className="text-lg font-black text-red-600">{inativos}</span>
          <div
            className="w-20 rounded-t-xl transition-all duration-700"
            style={{ height: `${hInativo || 6}px`, background: "linear-gradient(180deg, #ef4444, #dc2626)", minHeight: 6 }}
          />
          <span className="text-sm font-semibold text-[var(--text-muted)]">Inativos</span>
        </div>
      </div>
      <div className="flex justify-center gap-6 mt-3">
        <span className="text-sm text-[var(--text-muted)]">Total: <strong>{total}</strong></span>
        <span className="text-sm font-semibold text-green-600">{((ativos / total) * 100).toFixed(0)}% ativos</span>
      </div>
    </div>
  );
}

const PIZZA_COLORS = ["#003366","#0ea5e9","#22c55e","#f59e0b","#8b5cf6","#ef4444","#10b981","#f97316"];

function PizzaProgramas({ data }: { data: { label: string; value: number }[] }) {
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const cx = 100, cy = 100, r = 85;
  let startAngle = -Math.PI / 2;
  const slices = data.map((d, i) => {
    const angle = (d.value / total) * 2 * Math.PI;
    const endAngle = startAngle + angle;
    const x1 = cx + r * Math.cos(startAngle), y1 = cy + r * Math.sin(startAngle);
    const x2 = cx + r * Math.cos(endAngle),   y2 = cy + r * Math.sin(endAngle);
    const large = angle > Math.PI ? 1 : 0;
    const path = `M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2} Z`;
    startAngle = endAngle;
    return { path, color: PIZZA_COLORS[i % PIZZA_COLORS.length], label: d.label, value: d.value };
  });
  return (
    <div className="rounded-2xl p-5" style={{ background: "var(--surface-card)", border: "1px solid var(--surface-border)" }}>
      <p className="text-sm font-bold text-[var(--primary-color)] mb-4">Programas Ativos</p>
      <div className="flex items-center gap-5">
        <svg viewBox="0 0 200 200" className="w-40 h-40 flex-shrink-0">
          {slices.map((s, i) => <path key={i} d={s.path} fill={s.color} stroke="#fff" strokeWidth="1.5" />)}
          <circle cx={cx} cy={cy} r={r * 0.45} fill="var(--surface-card)" />
          <text x={cx} y={cy + 5} textAnchor="middle" fontSize="14" fontWeight="800" fill="var(--primary-color)">{data.length}</text>
          <text x={cx} y={cy + 18} textAnchor="middle" fontSize="9" fill="var(--text-muted)">programas</text>
        </svg>
        <div className="flex flex-col gap-2 flex-1 overflow-hidden">
          {slices.map((s, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: s.color }} />
              <span className="text-xs text-[var(--text-muted)] truncate flex-1">{s.label}</span>
              <span className="text-sm font-bold flex-shrink-0" style={{ color: s.color }}>{s.value}</span>
            </div>
          ))}
          {data.length === 0 && <span className="text-xs text-[var(--text-muted)]">Sem dados</span>}
        </div>
      </div>
    </div>
  );
}

function BarrasMensalBeneficiarios({ data }: { data: { month: string; year: number; total: number }[] }) {
  const max = Math.max(...data.map(d => d.total), 1);
  const BAR_H = 160;
  return (
    <div className="rounded-2xl p-5" style={{ background: "var(--surface-card)", border: "1px solid var(--surface-border)" }}>
      <p className="text-sm font-bold text-[var(--primary-color)] mb-4">Evolução Mensal de Beneficiários</p>
      <div className="overflow-x-auto pb-1">
        <div className="flex items-end gap-2" style={{ minWidth: `${data.length * 56}px`, height: `${BAR_H + 48}px` }}>
          {data.map((d, i) => {
            const h = Math.max(6, Math.round((d.total / max) * BAR_H));
            return (
              <div key={i} className="flex flex-col items-center gap-1 flex-shrink-0" style={{ width: 48 }}>
                <span className="text-xs font-bold text-[var(--primary-color)]">{d.total || ""}</span>
                <div
                  className="w-full rounded-t-xl transition-all duration-700"
                  style={{ height: `${h}px`, background: "linear-gradient(180deg, #0ea5e9, var(--primary-color))" }}
                />
                <span className="text-xs text-[var(--text-muted)] text-center leading-tight">
                  {d.month}<br /><span className="text-[10px]">{d.year}</span>
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function BarrasMensalFaturas({ data }: { data: { month: string; year: number; count: number; total: number }[] }) {
  const maxTotal = Math.max(...data.map(d => d.total), 1);
  const BAR_H = 100;
  const fmt = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
  return (
    <div className="rounded-2xl p-4" style={{ background: "var(--surface-card)", border: "1px solid var(--surface-border)" }}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-bold text-[var(--primary-color)]">Evolução de Faturas</p>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-2.5 rounded-sm bg-green-500" />
          <span className="text-xs text-[var(--text-muted)]">Valor por fatura</span>
        </div>
      </div>
      <div className="overflow-x-auto pb-1">
        <div className="flex items-end gap-3" style={{ minWidth: `${data.length * 64}px`, height: `${BAR_H + 52}px` }}>
          {data.map((d, i) => {
            const h = Math.max(6, Math.round((d.total / maxTotal) * BAR_H));
            return (
              <div key={i} className="flex flex-col items-center gap-1 flex-shrink-0" style={{ width: 56 }}>
                <span className="text-[9px] font-bold text-green-600">{d.total > 0 ? fmt(d.total) : ""}</span>
                <div className="flex items-end w-full justify-center" style={{ height: `${BAR_H}px` }}>
                  <div
                    className="rounded-t-md transition-all duration-700 w-full"
                    style={{ height: `${h}px`, background: "linear-gradient(180deg, #22c55e, #16a34a)" }}
                  />
                </div>
                <span className="text-xs text-[var(--text-muted)] text-center leading-tight">
                  {d.month}<br /><span className="text-[10px]">{d.year}</span>
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Tipos dos estados dos gráficos ──────────────────────────────────────────
type TSummary        = { movements: number; invoices: number; attachments: number; pendingMovements: number };
type TChartMovements = { ativos: number; inativos: number; porPrograma: { label: string; value: number }[]; porMes: { month: string; year: number; total: number }[] };
type TChartInvoices  = { porMes: { month: string; year: number; count: number; total: number }[] };

const initialChartMovements: TChartMovements = { ativos: 0, inativos: 0, porPrograma: [], porMes: [] };
const initialChartInvoices: TChartInvoices   = { porMes: [] };

// ═══════════════════════════════════════════════════════════════════════════
// COMPONENTE PRINCIPAL
// ═══════════════════════════════════════════════════════════════════════════
export default function B2BPanel() {
  const [, setLoading]              = useAtom(loadingAtom);
  const [userLogger]                = useAtom(userLoggerAtom);
  const [pagination, setPagination] = useAtom(paginationAtom);

  const [activeTab, setActiveTab]       = useState<TTab>("movements");
  const [typeModal, setTypeModal]       = useState<"create" | "edit">("create");
  const [currentBody, setCurrentBody]   = useState<any>({});
  const [modalDelete, setModalDelete]   = useState<boolean>(false);
  const [queryStr, setQueryStr]         = useState<string>("");
  const [exportingExcel, setExportingExcel] = useState(false);
  const [summary, setSummary]           = useState<TSummary>({ movements: 0, invoices: 0, attachments: 0, pendingMovements: 0 });
  const [chartMovements, setChartMovements] = useState<TChartMovements>(initialChartMovements);
  const [chartInvoices,  setChartInvoices]  = useState<TChartInvoices>(initialChartInvoices);
  const [modalMovement,   setModalMovement]   = useState(false);
  const [modalInvoice,    setModalInvoice]    = useState(false);
  const [modalAttachment, setModalAttachment] = useState(false);
  const [filterOpened, setFilterOpened] = useState(true);

  const { register, reset, getValues } = useForm<TFilter>({ defaultValues: ResetFilter });

  // ── Busca de dados ──────────────────────────────────────────────────────
  const getAll = useCallback(async (tab: TTab, query: string = "") => {
    try {
      setLoading(true);
      const uri = URI_MAP[tab];
      let finalQuery = query;
      if (uri === "attachments") {
        const contractorId = localStorage.getItem("contractorId") ?? "";
        if (contractorId) finalQuery += `&parentId=${contractorId}&parent=customer-manager`;
      }
      const { data } = await api.get(`/${uri}?deleted=false&orderBy=createdAt&sort=desc&pageSize=10&pageNumber=1${finalQuery}`, configApi());
      const result = data.result;
      setPagination({ currentPage: result.currentPage, data: result.data, sizePage: result.pageSize, totalPages: result.totalCount });
    } catch (error) { resolveResponse(error); } finally { setLoading(false); }
  }, [setLoading, setPagination]);

  const getRecipient = useCallback(async (query: string = "") => {
    try {
      setLoading(true);
      const contractorId = localStorage.getItem("contractorId") ?? "";
      const { data } = await api.get(
        `/customer-recipients/manager-panel?deleted=false&contractorId=${contractorId}&orderBy=name&sort=asc&pageSize=10&pageNumber=1${query}`,
        configApi()
      );
      const result = data.result;
      setPagination({ currentPage: result.currentPage, data: result.data, sizePage: result.pageSize, totalPages: result.totalCount });
    } catch (error) { resolveResponse(error); } finally { setLoading(false); }
  }, [setLoading, setPagination]);

  const exportExcel = async () => {
    try {
      setExportingExcel(true);
      const contractorId = localStorage.getItem("contractorId") ?? "";
      const { data } = await api.get(
        `/customer-recipients/manager-panel?deleted=false&contractorId=${contractorId}&orderBy=name&sort=asc&pageSize=99999&pageNumber=1${queryStr}`,
        configApi()
      );
      const rows: any[] = data.result.data ?? [];
      const sheetData = rows.map((r) => ({
        "Beneficiário":       r.name ?? "",
        "CPF":                r.cpf ?? "",
        "Status":             r.active ? "Ativo" : "Inativo",
        "Programa":           r.planName ?? "",
        "Função":             r.role ?? "",
        "Departamento":       r.department ?? "",
        "Sexo":               r.gender ?? "",
        "Data de Nascimento": r.dateOfBirth ? maskDate(r.dateOfBirth) : "",
        "Data de Vigência":   r.effectiveDate ? maskDate(r.effectiveDate) : "",
        "E-mail":             r.email ?? "",
        "Telefone":           r.phone ?? "",
        "WhatsApp":           r.whatsapp ?? "",
        "Vínculo":            r.bond ?? "",
        "CEP":                r?.address?.zipCode ?? "",
        "Número":             r?.address?.number ?? "",
        "Rua":                r?.address?.street ?? "",
        "Complemento":        r?.address?.complement ?? "",
        "Bairro":             r?.address?.neighborhood ?? "",
        "Cidade":             r?.address?.city ?? "",
        "Estado":             r?.address?.state ?? "",
      }));
      const XLSX = await import("xlsx");
      const ws = XLSX.utils.json_to_sheet(sheetData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Beneficiários");
      ws["!cols"] = Object.keys(sheetData[0] ?? {}).map(() => ({ wch: 24 }));
      XLSX.writeFile(wb, `beneficiarios_${new Date().toISOString().split("T")[0]}.xlsx`);
    } catch (error) { resolveResponse(error); } finally { setExportingExcel(false); }
  };

  const loadSummary = useCallback(async () => {
    try {
      const idLocal = localStorage.getItem("id") ?? "";
      const [mov, inv, att, pending] = await Promise.all([
        api.get(`/b2b-mass-movements?deleted=false&pageSize=1&pageNumber=1`, configApi()),
        api.get(`/b2b-invoices?deleted=false&pageSize=1&pageNumber=1`, configApi()),
        api.get(`/attachments?deleted=false&pageSize=1&pageNumber=1&parentId=${idLocal}&parent=customer-manager`, configApi()),
        api.get(`/b2b-mass-movements?deleted=false&status=Pendente&pageSize=1&pageNumber=1`, configApi()),
      ]);
      setSummary({
        movements:        mov.data.result.totalCount,
        invoices:         inv.data.result.totalCount,
        attachments:      att.data.result.totalCount,
        pendingMovements: pending.data.result.totalCount,
      });
    } catch {}
  }, []);

  const loadChartMovements = useCallback(async () => {
    try {
      const contractorId = localStorage.getItem("contractorId") ?? "";
      const { data } = await api.get(
        `/customer-recipients/manager-panel?deleted=false&contractorId=${contractorId}&orderBy=name&sort=asc&pageSize=99999&pageNumber=1`,
        configApi()
      );
      const rows: any[] = data.result.data ?? [];

      const ativos   = rows.filter((r) => r.active).length;
      const inativos = rows.filter((r) => !r.active).length;

      const programaMap: Record<string, number> = {};
      rows.forEach((r) => {
        if (r.planName) programaMap[r.planName] = (programaMap[r.planName] ?? 0) + 1;
      });
      const porPrograma = Object.entries(programaMap).map(([label, value]) => ({ label, value }));

      const mesMap: Record<string, number> = {};
      rows.forEach((r) => {
        if (r.effectiveDate) {
          const d = new Date(r.effectiveDate);
          const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
          mesMap[key] = (mesMap[key] ?? 0) + 1;
        }
      });
      const porMes = Object.entries(mesMap)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, total]) => {
          const [year, month] = key.split("-");
          return { month: MONTHS_SHORT[Number(month) - 1], year: Number(year), total };
        });

      setChartMovements({ ativos, inativos, porPrograma, porMes });
    } catch {}
  }, []);

  const loadChartInvoices = useCallback(async () => {
    try {
      const { data } = await api.get(
        `/b2b-invoices?deleted=false&orderBy=createdAt&sort=asc&pageSize=99999&pageNumber=1`,
        configApi()
      );
      const rows: any[] = data.result.data ?? [];

      const mesMap: Record<string, { count: number; total: number }> = {};
      rows.forEach((r) => {
        const key = `${r.referenceYear ?? "0000"}-${String(r.referenceMonth ?? 1).padStart(2, "0")}`;
        if (!mesMap[key]) mesMap[key] = { count: 0, total: 0 };
        mesMap[key].count += 1;
        mesMap[key].total += Number(r.totalAmount ?? 0);
      });
      const porMes = Object.entries(mesMap)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([key, val]) => {
          const [year, month] = key.split("-");
          return { month: MONTHS_SHORT[Number(month) - 1], year: Number(year), ...val };
        });

      setChartInvoices({ porMes });
    } catch {}
  }, []);

  // ── Filtro / submit ─────────────────────────────────────────────────────
  const buildQuery = (values: TFilter): string => {
    let q = "";
    if (values.search)            q += `&regex$or$name=${values.search}`;
    if (values["gte$createdAt"])  q += `&gte$createdAt=${values["gte$createdAt"]}`;
    if (values["lte$createdAt"])  q += `&lte$createdAt=${values["lte$createdAt"]}`;
    if (values.status)            q += `&status=${values.status}`;
    if (values.type)              q += `&type=${values.type}`;
    if (values.customerId)        q += `&customerId=${values.customerId}`;
    if (values.department)        q += `&regex$department=${values.department}`;
    if (values.period)            q += `&period=${values.period}`;
    if (values.referenceMonth)    q += `&referenceMonth=${values.referenceMonth}`;
    if (values.referenceYear)     q += `&referenceYear=${values.referenceYear}`;
    return q;
  };

  const onSubmit = async () => {
    const q = buildQuery(getValues());
    setQueryStr(q);
    activeTab === "movements" ? await getRecipient(q) : await getAll(activeTab, q);
  };

  // ── Modais ──────────────────────────────────────────────────────────────
  const openModal = (action: "create" | "edit" = "create", body?: any) => {
    if (body) { setCurrentBody(body); }
    setTypeModal(action);
    if (activeTab === "movements")   setModalMovement(true);
    if (activeTab === "invoices")    setModalInvoice(true);
    if (activeTab === "attachments") setModalAttachment(true);
  };

  const closeModal = () => {
    setModalMovement(false);
    setModalInvoice(false);
    setModalAttachment(false);
    setCurrentBody({});
  };

  const handleSuccess = async () => {
    closeModal();
    activeTab === "movements" ? await getRecipient(queryStr) : await getAll(activeTab, queryStr);
    await loadSummary();
    if (activeTab === "movements") await loadChartMovements();
    if (activeTab === "invoices")  await loadChartInvoices();
  };

  const openModalDelete = (body: any) => { setCurrentBody(body); setModalDelete(true); };

  const destroy = async () => {
    try {
      const uri = URI_MAP[activeTab];
      const { status } = await api.delete(`/${uri}/${currentBody?.id}`, configApi());
      resolveResponse({ status, message: "Excluído com sucesso" });
      setModalDelete(false);
      setCurrentBody({});
      activeTab === "movements" ? await getRecipient(queryStr) : await getAll(activeTab, queryStr);
      await loadSummary();
    } catch (error) { resolveResponse(error); }
  };

  // ── Colunas / células ───────────────────────────────────────────────────
  const columns = useMemo(() => {
    if (activeTab === "movements") return movementColumns;
    if (activeTab === "invoices")  return invoiceColumns;
    return attachmentColumns;
  }, [activeTab]);

  const renderCell = (x: any, col: { key: string; title: string }) => {
    const v = x[col.key];
    if (["createdAt","dueDate","paidAt","effectiveDate","closingDate"].includes(col.key)) return maskDate(v);
    if (col.key === "totalAmount")    return convertNumberMoney(v);
    if (col.key === "active")         return <StatusBadge value={v ? "Ativo" : "Inativo"} />;
    if (col.key === "status")         return <StatusBadge value={v} />;
    if (col.key === "Visualizar")     return <IconView link={x.uri} />;
    if (col.key === "referenceMonth") return `${String(x.referenceMonth).padStart(2, "0")}/${x.referenceYear}`;
    if (col.key === "type") {
      const map: Record<string, string> = {
        Inclusao:          "Inclusão",
        Exclusao:          "Exclusão",
        UpgradePrograma:   "Upgrade",
        DowngradePrograma: "Downgrade",
      };
      return map[v] ?? v;
    }
    return v;
  };

  // ── Effects ─────────────────────────────────────────────────────────────
  useEffect(() => {
    loadSummary();
    loadChartMovements();
    getRecipient();
  }, []);

  useEffect(() => {
    reset(ResetFilter);
    setQueryStr("");
    if (activeTab === "movements") {
      getRecipient();
      loadChartMovements();
    } else {
      getAll(activeTab);
      if (activeTab === "invoices") loadChartInvoices();
    }
  }, [activeTab]);

  // ── Tabs config ─────────────────────────────────────────────────────────
  const tabs: { key: TTab; label: string; icon: React.ReactNode; count?: number }[] = [
    { key: "movements",   label: "Movimentação de Massa", icon: <FiUsers size={15} />,             count: summary.movements },
    { key: "invoices",    label: "Painel de Faturas",     icon: <MdOutlineReceipt size={15} />,    count: summary.invoices },
    { key: "attachments", label: "Anexos",                icon: <MdOutlineAttachFile size={15} />, count: summary.attachments },
  ];

  return (
    <>
      <Autorization />
      {userLogger ? (
        <>
          <Header />
          <main className="slim-bg-main">
            <SideMenu />
            <div className="slim-container-customer h-[calc(100dvh-5rem)] w-full overflow-y-auto">
              <SlimContainer
                menu="Gestão"
                breadcrump="Painel do Gestor"
                breadcrumpIcon="MdBusiness"
                buttons={
                  <div className="flex items-center gap-2">
                    {activeTab === "movements" && (
                      <button onClick={exportExcel} disabled={exportingExcel} className="slim-btn slim-btn-primary-light flex items-center gap-1.5">
                        <FiDownload size={14} />{exportingExcel ? "Exportando..." : "Exportar Excel"}
                      </button>
                    )}
                    {activeTab !== "invoices" && (
                      <button onClick={() => openModal()} className="slim-btn slim-btn-primary">
                        Adicionar
                      </button>
                    )}
                  </div>
                }
              >
                {/* ── Summary Cards ─────────────────────────────────────── */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                  {[
                    { label: "Movimentações",  value: summary.movements,        color: "var(--primary-color)" },
                    { label: "Faturas",         value: summary.invoices,          color: "#3b82f6" },
                    { label: "Anexos",          value: summary.attachments,       color: "#8b5cf6" },
                    { label: "Mov. Pendentes",  value: summary.pendingMovements,  color: "#f59e0b" },
                  ].map((c) => (
                    <div
                      key={c.label}
                      className="rounded-xl p-4 flex flex-col gap-1"
                      style={{ background: "var(--surface-card)", border: "1px solid var(--surface-border)" }}
                    >
                      <span className="text-xs text-[var(--text-muted)] font-medium">{c.label}</span>
                      <span className="text-2xl font-bold" style={{ color: c.color }}>{c.value}</span>
                    </div>
                  ))}
                </div>

                {/* ── Tabs ──────────────────────────────────────────────── */}
                <div className="flex gap-1 mb-4 p-1 rounded-xl" style={{ background: "var(--surface-bg)", border: "1px solid var(--surface-border)" }}>
                  {tabs.map((t) => (
                    <button
                      key={t.key}
                      onClick={() => setActiveTab(t.key)}
                      className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all"
                      style={
                        activeTab === t.key
                          ? { background: "var(--primary-color)", color: "#fff", boxShadow: "0 2px 8px rgba(0,51,102,.25)" }
                          : { color: "var(--text-muted)" }
                      }
                    >
                      {t.icon}
                      <span className="hidden sm:inline">{t.label}</span>
                      {t.count !== undefined && (
                        <span
                          className="ml-1 px-1.5 py-0.5 rounded-full text-xs font-bold"
                          style={
                            activeTab === t.key
                              ? { background: "rgba(255,255,255,.25)", color: "#fff" }
                              : { background: "var(--surface-border)", color: "var(--text-muted)" }
                          }
                        >
                          {t.count}
                        </span>
                      )}
                    </button>
                  ))}
                </div>

                {/* ── Gráficos movements ─────────────────────────────────── */}
                {activeTab === "movements" && (
                  <div className="flex flex-col gap-3 mb-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <ColunasAtivosInativos ativos={chartMovements.ativos} inativos={chartMovements.inativos} />
                      <PizzaProgramas data={chartMovements.porPrograma} />
                    </div>
                    <BarrasMensalBeneficiarios data={chartMovements.porMes} />
                  </div>
                )}

                {/* ── Gráfico invoices ───────────────────────────────────── */}
                {activeTab === "invoices" && (
                  <div className="mb-4">
                    <BarrasMensalFaturas data={chartInvoices.porMes} />
                  </div>
                )}

                {/* ── Filtros ────────────────────────────────────────────── */}
                <div className="grid grid-cols-12 mb-2">
                  <Accordion className="col-span-12" defaultOpenId="filter">
                    <AccordionItem id="filter">
                      <AccordionTrigger
                        clickHeader={() => setFilterOpened((prev) => !prev)}
                        icon={queryStr ? <MdFilterAlt size={15} /> : <MdFilterAltOff size={15} />}
                        subtitle=""
                      >
                        Filtros
                      </AccordionTrigger>
                      <AccordionContent>
                        <div className="grid grid-cols-12 gap-3">

                          {/* Campo de busca — apenas movements ou attachments */}
                          {(activeTab === "movements" || activeTab === "attachments") && (
                            <div className="flex flex-col col-span-12 sm:col-span-4 mb-2">
                              <label className="label slim-label-primary">Busca rápida</label>
                              <input
                                {...register("search")}
                                type="text"
                                className="input slim-input-primary"
                                placeholder={activeTab === "attachments" ? "Nome do anexo..." : "Busca rápida..."}
                              />
                            </div>
                          )}

                          <div className="flex flex-col col-span-6 sm:col-span-2 mb-2">
                            <label className="label slim-label-primary">Data — início</label>
                            <input {...register("gte$createdAt")} type="date" className="input slim-input-primary" />
                          </div>

                          <div className="flex flex-col col-span-6 sm:col-span-2 mb-2">
                            <label className="label slim-label-primary">Data — fim</label>
                            <input {...register("lte$createdAt")} type="date" className="input slim-input-primary" />
                          </div>

                          {activeTab === "invoices" && (
                            <>
                              <div className="flex flex-col col-span-6 sm:col-span-2 mb-2">
                                <label className="label slim-label-primary">Mês</label>
                                <select {...register("referenceMonth")} className="select slim-select-primary">
                                  <option value="">Todos</option>
                                  {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
                                </select>
                              </div>
                              <div className="flex flex-col col-span-6 sm:col-span-2 mb-2">
                                <label className="label slim-label-primary">Ano</label>
                                <input
                                  {...register("referenceYear")}
                                  type="number"
                                  className="input slim-input-primary"
                                  placeholder={String(new Date().getFullYear())}
                                />
                              </div>
                              <div className="flex flex-col col-span-6 sm:col-span-2 mb-2">
                                <label className="label slim-label-primary">Status</label>
                                <select {...register("status")} className="select slim-select-primary">
                                  <option value="">Todos</option>
                                  <option value="Aberta">Aberta</option>
                                  <option value="Fechada">Fechada</option>
                                  <option value="Paga">Paga</option>
                                  <option value="Cancelada">Cancelada</option>
                                </select>
                              </div>
                            </>
                          )}

                          <div className="flex flex-col justify-end col-span-12 sm:col-span-1 mb-2">
                            <div onClick={onSubmit} className="slim-bg-primary p-2 w-10 flex justify-center items-center rounded-lg cursor-pointer">
                              <IoSearch />
                            </div>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  </Accordion>
                </div>

                {/* ── Tabela ────────────────────────────────────────────── */}
                <DataTable
                  isAction={activeTab === "invoices" || activeTab === "attachments"}
                  classContainer={`${filterOpened ? "max-h-[calc(100dvh-(var(--height-header)+23rem))]" : "max-h-[calc(100dvh-(var(--height-header)+16rem))]"}`}
                  columns={columns}
                >
                  <>
                    {pagination.data.map((x: any, i: number) => (
                      <tr className="slim-tr" key={i}>
                        {columns.map((col) =>
                          col.key.toLowerCase() !== "ações" && (
                            <td className="px-4 py-3 text-left text-sm font-medium tracking-wider" key={col.key}>
                              {renderCell(x, col)}
                            </td>
                          )
                        )}

                        {activeTab === "invoices" && (
                          <td className="text-center">
                            <div className="flex justify-center gap-2">
                              <IconEdit action="edit" obj={x} getObj={openModal} />
                            </div>
                          </td>
                        )}

                        {activeTab === "attachments" && (
                          <td className="text-center">
                            <div className="flex justify-center gap-2">
                              <IconDelete obj={x} getObj={openModalDelete} />
                              <IconView link={x.uri} />
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </>
                </DataTable>
                <NotData />
              </SlimContainer>
            </div>

            {/* ── Modais ────────────────────────────────────────────────── */}
            <ModalB2BMassMovement
              isOpen={modalMovement}
              typeModal={typeModal}
              body={currentBody}
              customers={[]}
              onClose={closeModal}
              onSuccess={handleSuccess}
            />

            <ModalB2BInvoice
              isOpen={modalInvoice}
              typeModal={typeModal}
              body={currentBody}
              customers={[]}
              onClose={closeModal}
              onSuccess={handleSuccess}
            />

            <ModalB2BAttachment
              isOpen={modalAttachment}
              typeModal={typeModal}
              body={currentBody}
              customers={[]}
              onClose={closeModal}
              onSuccess={handleSuccess}
            />

            <ModalDelete
              title="Excluir registro"
              isOpen={modalDelete}
              setIsOpen={() => setModalDelete(false)}
              onClose={() => setModalDelete(false)}
              onSelectValue={destroy}
            />
          </main>
        </>
      ) : <></>}
    </>
  );
}