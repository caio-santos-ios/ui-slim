"use client";

import { ModalDelete } from "@/components/Global/ModalDelete";
import { useState } from "react";
import { api, uriBase } from "@/service/api.service";
import { configApi, resolveResponse } from "@/service/config.service";
import { IconEdit } from "@/components/Global/IconEdit";
import { IconDelete } from "@/components/Global/IconDelete";
import { ModalUser } from "../Modal";
import { TUser } from "@/types/masterData/user/user.type";
import { permissionDelete, permissionUpdate } from "@/utils/permission.util";
import { IconEditPhoto } from "../IconEditPhoto";
import { ModalPhoto } from "../ModalPhoto";

type TProp = {
    list: TUser[],
    handleReturnModal: (isSuccess: boolean) => void;
}

export const TableUser = ({list, handleReturnModal}: TProp) => {
    const [modalDelete, setModalDelete] = useState<boolean>(false);
    const [modal, setModal] = useState<boolean>(false);
    const [modalUpdatePhoto, setModalUpdatePhoto] = useState<boolean>(false);
    const [id, setId] = useState<string>("")

    const getCurrentBody = (action: string, body: TUser, ) => {
        setId(body.id!);

        if(action == "edit") {
            setModal(true)
        };

        if(action == "editPhoto") {
            setModalUpdatePhoto(true);
        };
    };
    
    const getDestroy = (body: TUser) => {
        setModalDelete(true);
        setId(body.id!)
    };

    const destroy = async () => {
        try {
            const { status } = await api.delete(`/users/${id}`, configApi());
            resolveResponse({status, message: "Excluído com sucesso"});
            setModalDelete(false);
            handleReturnModal(true);
        } catch (error) {
            resolveResponse(error);
        }
    };

    const onClose = () => {
        setId("");
        setModal(false);
        setModalUpdatePhoto(false);
        handleReturnModal(true);
    };

    const handleReturn = () => {
        onClose();
    };

    const validatedImage = (uri: string) =>  {
        if(!uri) return '/erp/assets/images/notImage.png';

        return `${uriBase}/${uri}`;
    };

    return (
        <>
            {
                list.length > 0 &&
                <div className="slim-container-table w-full">
                    <table className="min-w-full divide-y">
                        <thead className="slim-table-thead">
                            <tr>
                                <th scope="col" className={`px-4 py-3 text-left text-sm font-bold tracking-wider rounded-tl-xl`}>Nome</th>
                                <th scope="col" className={`px-4 py-3 text-left text-sm font-bold tracking-wider`}>E-mail</th>
                                <th scope="col" className={`px-4 py-3 text-left text-sm font-bold tracking-wider`}>Admin</th>
                                <th scope="col" className={`px-4 py-3 text-left text-sm font-bold tracking-wider`}>Bloqueado</th>
                                <th scope="col" className={`px-4 py-3 text-center text-sm font-bold tracking-wider rounded-tr-xl`}>Ações</th>
                            </tr>
                        </thead>

                        <tbody className="slim-body-table divide-y">
                            {
                                list.map((x: any) => {
                                    return (
                                        <tr className="slim-tr" key={x.id}>                                            
                                            <td className="px-4 py-2">
                                                <div className="flex items-center gap-2">

                                                    <img className="w-20 h-20 max-h-56 object-cover rounded-full" src={validatedImage(x.photo)} alt="foto do usuário" />
                                                    {x.name}
                                                </div>
                                            </td>
                                            <td className="px-4 py-2">{x.email}</td>
                                            <td className="px-4 py-2">{x.admin ? "Sim" : "Não"}</td>
                                            <td className="px-4 py-2">{x.blocked ? "Sim" : "Não"}</td>
                                            <td className="p-2">
                                                <div className="flex justify-center gap-3">
                                                    {
                                                        permissionUpdate("1", "A11") &&
                                                        <IconEdit action="edit" obj={x} getObj={getCurrentBody}/>
                                                    }                                                    
                                                    {
                                                        permissionUpdate("1", "A11") &&
                                                        <IconEditPhoto action="editPhoto" obj={x} getObj={getCurrentBody}/>
                                                    }                                                    
                                                    {
                                                        permissionDelete("1", "A11") &&
                                                        <IconDelete obj={x} getObj={getDestroy}/>                                                   
                                                    }
                                                </div>
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </table>
                </div>
            }

            <ModalUser
                title='Editar Usuário' 
                isOpen={modal} setIsOpen={() => setModal(modal)} 
                onClose={onClose}
                handleReturnModal={handleReturn}
                id={id}
            />     
            
            <ModalPhoto
                isOpen={modalUpdatePhoto} setIsOpen={() => setModalUpdatePhoto(modalUpdatePhoto)} 
                onClose={onClose}
                handleReturnModal={handleReturn}
                id={id}
            />     

            <ModalDelete
                title='Excluír Usuário'
                isOpen={modalDelete} setIsOpen={() => setModalDelete(!modalDelete)} 
                onClose={() => setModalDelete(false)}
                onSelectValue={destroy}
            />  
        </>
    )
}