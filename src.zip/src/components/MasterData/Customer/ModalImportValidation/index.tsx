"use client";

import "./style.css";
import { Button } from "@/components/Global/Button";

export type TImportRow = {
  index: number;
  name: string;
  cpf: string;
  email: string;
  phone: string;
  bond: string;
  errors: string[];
};

type TProp = {
  isOpen: boolean;
  onClose: () => void;
  rows: TImportRow[];
  onConfirm: () => void;
  importing: boolean;
};
const isValidCPF = (cpf: string): boolean => {

  if (/^(.)\1+$/.test(cpf)) return false;

  let sum = 0;
  for (let i = 1; i <= 9; i++) sum += parseInt(cpf[i - 1]) * (11 - i);
  let rest = (sum * 10) % 11;
  if (rest === 10 || rest === 11) rest = 0;
  if (rest !== parseInt(cpf[9])) return false;

  sum = 0;
  for (let i = 1; i <= 10; i++) sum += parseInt(cpf[i - 1]) * (12 - i);
  rest = (sum * 10) % 11;
  if (rest === 10 || rest === 11) rest = 0;
  return rest === parseInt(cpf[10]);
};

export const validateImportRows = (rawRows: any[]): TImportRow[] => {
  return rawRows.map((row: any, i: number) => {
    const errors: string[] = [];

    const cpfRaw = String(row["CPF"] ?? row["cpf"] ?? "").trim();
    const cpfDigits = cpfRaw.replace(/\D/g, "");

    if (!cpfRaw) {
      errors.push("CPF obrigatório");
    } else if (cpfDigits.length !== 11) {
      errors.push("CPF incompleto");
    } else if (!isValidCPF(cpfDigits)) {
      errors.push("CPF inválido");
    }

    const name = String(row["Nome"] ?? row["name"] ?? row["NOME"] ?? "").trim();
    if (!name) errors.push("Nome obrigatório");

    return {
      index: i + 1,
      name,
      cpf: cpfRaw,
      email: String(row["Email"] ?? row["E-mail"] ?? row["email"] ?? "").trim(),
      phone: String(row["Telefone"] ?? row["phone"] ?? row["TELEFONE"] ?? "").trim(),
      bond: String(row["Vínculo"] ?? row["Vinculo"] ?? row["bond"] ?? "").trim(),
      errors,
    };
  });
};

export const ModalImportValidation = ({
  isOpen,
  onClose,
  rows,
  onConfirm,
  importing,
}: TProp) => {
  if (!isOpen) return null;

  const validRows   = rows.filter((r) => r.errors.length === 0);
  const invalidRows = rows.filter((r) => r.errors.length > 0);
  const canConfirm = invalidRows.length === 0 && !importing;
  return (
    <div className="import-validation-overlay">
      <div className="import-validation-modal">

        <div className="import-validation-header">
          <h2>Validação de Importação</h2>
 
          <button
            type="button"
            onClick={onClose}
            title="Fechar"
            disabled={importing}
            style={{ opacity: importing ? 0.4 : 1, cursor: importing ? "not-allowed" : "pointer" }}
          >
            ✕
          </button>
        </div>

        <div className="import-validation-summary">
          <span className="import-summary-badge total">Total: {rows.length}</span>
          <span className="import-summary-badge valid">✓ Válidos: {validRows.length}</span>
          {invalidRows.length > 0 && (
            <span className="import-summary-badge invalid">
              ✗ Com erro: {invalidRows.length}
            </span>
          )}
        </div>

        <div className="import-validation-body">
          <table className="import-validation-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Nome</th>
                <th>CPF</th>
                <th>E-mail</th>
                <th>Telefone</th>
                <th>Vínculo</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.index}
                  className={row.errors.length > 0 ? "row-error" : "row-valid"}
                >
                  <td>{row.index}</td>
                  <td>
                    {row.name || <span style={{ color: "#b91c1c" }}>—</span>}
                  </td>
                  <td>
                    {row.cpf || <span style={{ color: "#b91c1c" }}>—</span>}
                  </td>
                  <td>{row.email || "—"}</td>
                  <td>{row.phone || "—"}</td>
                  <td>{row.bond  || "—"}</td>
                  <td>
                    {row.errors.length === 0 ? (
                      <span className="status-badge ok">✓ OK</span>
                    ) : (
                      <span
                        className="status-badge error"
                        title={row.errors.join(", ")}
                      >
                        ✗ {row.errors.join(", ")}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="import-validation-footer">
          {invalidRows.length > 0 && (
            <span
              style={{ fontSize: "0.8125rem", color: "#b91c1c", marginRight: "auto" }}
            >
              ⚠ Corrija os erros antes de importar.
            </span>
          )}

          <Button
            type="button"
            click={onClose}
            text="Cancelar"
            theme="primary-light"
            styleClassBtn=""
            disabled={importing}
          />

          <Button
            type="button"
            click={onConfirm}
            text={
              importing
                ? "Importando..."
                : `Adicionar (${validRows.length} registro${validRows.length !== 1 ? "s" : ""})`
            }
            theme="primary"
            styleClassBtn=""
            disabled={!canConfirm}
          />
        </div>

      </div>
    </div>
  );
};
