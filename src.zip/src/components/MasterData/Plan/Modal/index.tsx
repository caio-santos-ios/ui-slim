"use client";

import "./style.css";
import { Dialog, DialogPanel, DialogTitle } from '@headlessui/react';
import { SubmitHandler, useForm } from "react-hook-form";
import { configApi, resolveResponse } from "@/service/config.service";
import { api, uriBase } from "@/service/api.service";
import { useEffect, useState } from "react";
import { Button } from "@/components/Global/Button";
import { maskMoney } from "@/utils/mask.util";
import { loadingAtom } from "@/jotai/global/loading.jotai";
import { useAtom } from "jotai";
import { toast } from "react-toastify";
import { convertMoneyToNumber, convertNumberMoney, convertStringMoney } from "@/utils/convert.util";
import { ResetPlan, TPlan } from "@/types/masterData/plans/plans.type";
import MultiSelect from "@/components/Global/MultiSelect";
import { TServiceModule } from "@/types/masterData/serviceModules/serviceModules.type";
import { IoClose } from "react-icons/io5";

type TProp = {
    title: string;
    isOpen: boolean;
    setIsOpen: (isOpen: boolean) => void;
    onClose: () => void;
    onSelectValue: (isSuccess: boolean, onCloseModal?: boolean) => void;
    body?: TPlan
}

export const ModalPlan = ({title, isOpen, setIsOpen, onClose, onSelectValue, body}: TProp) => {
    const [_, setLoading] = useAtom(loadingAtom);
    const [serviceModules, setServiceModule] = useState([]);
    const [modules, setModules] = useState<TServiceModule[]>([]);
    const { register, handleSubmit, reset, watch, setValue, formState: { errors }} = useForm<TPlan>();
    const currentImage = watch("uri");

    const onSubmit: SubmitHandler<TPlan> = async (body: TPlan) => {
        body.serviceModuleIds = modules.map(x => x.id!).join(",");
        const formBody = new FormData();

        formBody.append("description", body.description);
        formBody.append("active", body.active);
        formBody.append("cost", convertMoneyToNumber(body.cost) as any);
        formBody.append("price", convertMoneyToNumber(body.price) as any);
        formBody.append("name", body.name);
        formBody.append("type", body.type);
        formBody.append("uri", body.uri);
        if(body.serviceModuleIds) {
            formBody.append("listServiceModuleIds", body.serviceModuleIds);
        };

        const attachment: any = document.querySelector('#image');
        if (attachment.files[0]) formBody.append('image', attachment.files[0]);
        
        if(!body.id) {
            await create(formBody);
        } else {
            formBody.append("uri", body.image);
            formBody.append("id", body.id);
            await update(formBody);
        }
    };

    const create = async (form: FormData) => {
        try {
            const { status, data} = await api.post(`/plans`, form, configApi(false));
            resolveResponse({status, ...data});
            cancel();
            onSelectValue(true);
        } catch (error) {
            resolveResponse(error);
        }
    };
      
    const update = async (form: FormData) => {
        try {
            const { status, data} = await api.put(`/plans`, form, configApi(false));
            resolveResponse({status, ...data});
            cancel();
            onSelectValue(true);
        } catch (error) {
            resolveResponse(error);
        }
    };
    
    const updateImage = async (form: FormData) => {
        try {
            const { status, data} = await api.put(`/plans/save-image`, form, configApi(false));
            resolveResponse({status, ...data});

            const newImage = data.result.data.image;

            setValue("uri", newImage);
            onSelectValue(true, false);
        } catch (error) {
            resolveResponse(error);
        }
    };

    const cancel = () => {
        reset({...ResetPlan, serviceModuleIds: []});
        onClose();
    };

    const getSelectServiceModule = async () => {
        try {
            setLoading(true);
            const {data} = await api.get(`/service-modules?deleted=false&pageSize=100&pageNumber=1`, configApi());
            const result = data.result;    
            setServiceModule(result.data);
        } catch (error) {
            resolveResponse(error);
        } finally {
            setLoading(false);
        }
    };

    const selectModule = (module: TServiceModule[]) => {
        setModules(module)
    };

    const validatedImage = (uri: string) =>  {
        if(!uri) return '/assets/images/notImage.png';

        return `${uriBase}/${uri}`;
    };

    useEffect(() => {
        reset(ResetPlan);

        if(body) {
            body.price = convertNumberMoney(body.price);
            body.cost = convertNumberMoney(body.cost);
            reset(body);
            setModules(body.serviceModuleIds);
        };
    }, [body]);
    
    useEffect(() => {
        getSelectServiceModule();
    }, []);

    const validatedField = () => {
        const errorPriority = [
            "name",
            "price",
            "description",
        ];

        const getErrorByPath = (path: string) => {
            const parts = path.split(".");
            let current: any = errors;

            for (const part of parts) {
                if (!current[part]) return null;
                current = current[part];
            }

            return current.message || null;
        };

        for (const field of errorPriority) {
            const message = getErrorByPath(field);

            if (message) {
                toast.warn(message, { theme: "colored" });
                return; 
            }
        }
    };

    useEffect(() => {
        const attachment: any = document.querySelector('#image');
        if(attachment) {
            if(attachment.files.length > 0) {
                const formBody = new FormData();
                
                if (attachment.files[0]) formBody.append('image', attachment.files[0]);
                if(body?.id) {
                    formBody.append("id", body.id);
                };
                updateImage(formBody);
            };
        };
    }, [watch("image")]);

    return (
        <>
            <Dialog
                open={isOpen}
                as="div"
                className="relative z-[999] focus:outline-none"
                onClose={cancel}
            >
                {/* Backdrop */}
                <div
                    className="fixed inset-0 z-[999]"
                    style={{ background: "rgba(0,15,35,.65)", backdropFilter: "blur(5px)" }}
                />

                <div className="fixed inset-0 z-[1000] flex items-start justify-center pt-14 px-4 pb-6 overflow-y-auto">
                    <DialogPanel
                        className="w-full max-w-xl rounded-2xl overflow-hidden shadow-2xl"
                        style={{
                            background: "var(--surface-card)",
                            border: "1px solid var(--surface-border)",
                            animation: "modal-slide-in .25s cubic-bezier(.34,1.56,.64,1)",
                        }}
                    >
                        {/* ── Header ── */}
                        <div
                            className="flex items-center justify-between px-6 py-0 h-14"
                            style={{
                                background: "linear-gradient(135deg, var(--primary-color-light) 0%, var(--primary-color) 100%)",
                            }}
                        >
                            <DialogTitle as="h2" className="text-sm font-bold text-white">
                                {title}
                            </DialogTitle>
                            <span
                                onClick={cancel}
                                className="flex items-center justify-center w-8 h-8 rounded-lg transition-all cursor-pointer"
                                style={{ background: "rgba(255,255,255,.1)", border: "none", boxShadow: "none", color: "rgba(255,255,255,.7)" }}
                            >
                                <IoClose size={18} />
                            </span>
                        </div>

                        {/* ── Body ── */}
                        <div className="p-6 overflow-y-auto" style={{ maxHeight: "calc(100dvh - 16rem)" }}>
                            <form onSubmit={handleSubmit(onSubmit)}>
                            <div className="grid grid-cols-1 lg:grid-cols-8 gap-2 mb-2">
                                <div className={`flex flex-col col-span-3 justify-center items-center`}>
                                    <label htmlFor="image" className={`label slim-label-primary w-42 h-42 object-cover cursor-pointer`}>
                                        <img className="w-full h-full object-cover rounded-full" src={validatedImage(currentImage)} alt="foto do plano" />
                                        <input hidden id="image" {...register("image")} type="file" className={`input slim-input-primary`} placeholder="Digite"/>
                                    </label>
                                </div>

                                <div className={`flex flex-col col-span-5`}>
                                    <div className="flex flex-col mb-2">
                                        <label className={`label slim-label-primary`}>Nome</label>
                                        <input {...register("name", {required: "Nome é obrigatório"})} type="text" className={`input slim-input-primary`} placeholder="Digite"/>
                                    </div>
                                    <div className={`flex flex-col mb-2`}>
                                        <label className={`label slim-label-primary`}>Custo</label>
                                        <input onInput={(e: React.ChangeEvent<HTMLInputElement>) => maskMoney(e)} {...register("cost", {required: "Custo é obrigatório"})} type="text" className={`input slim-input-primary`} placeholder="Digite"/>
                                    </div>  
                                    <div className={`flex flex-col mb-2`}>
                                        <label className={`label slim-label-primary`}>Preço</label>
                                        <input onInput={(e: React.ChangeEvent<HTMLInputElement>) => maskMoney(e)} {...register("price", {required: "Preço é obrigatório"})} type="text" className={`input slim-input-primary`} placeholder="Digite"/>
                                    </div>      
                                </div>                                         
                                <div className={`flex flex-col col-span-3 mb-2`}>
                                    <label className={`label slim-label-primary`}>Tipo</label>
                                    <select className="select slim-select-primary" {...register("type", {required: "Tipo é obrigatório"})}>
                                        <option value="">Selecione</option>                                       
                                        <option value="B2B">B2B</option>                                       
                                        <option value="B2C">B2C</option>                                       
                                        <option value="B2B e B2C">B2B e B2C</option>                                       
                                    </select>
                                </div>                            
                                <div className={`flex flex-col col-span-5 mb-2`}>
                                    <label className={`label slim-label-primary`}>Programa</label>                                  
                                    <MultiSelect maxSelected={2} descriptionSelectedMax="Módulos Selecionados" value={body?.serviceModuleIds ?? []} onChange={(items) => selectModule(items)} options={serviceModules} labelKey="name" valueKey="id" />
                                </div>                            
                                <div className={`flex flex-col col-span-7 mb-2`}>
                                    <label className={`label slim-label-primary`}>Descrição</label>
                                    <input {...register("description", {required: "Descrição é obrigatório"})} type="text" className={`input slim-input-primary`} placeholder="Digite"/>
                                </div>   
                                <div className={`flex flex-col mb-2`}>
                                    <label className={`label slim-label-primary`}>Status</label>
                                    <label className="slim-switch">
                                        <input {...register("active")} type="checkbox"/>
                                        <span className="slider"></span>
                                    </label>
                                </div>                              
                            </div>                          
                                                   
                            <div className="flex justify-end gap-2 w-12/12 mt-3">
                                <Button type="button" click={cancel} text="Cancelar" theme="primary-light" styleClassBtn=""/>
                                <Button type="submit" click={validatedField} text="Salvar" theme="primary" styleClassBtn=""/>
                            </div>  
                        </form>
                        </div>

                    </DialogPanel>
                </div>
            </Dialog>
        </>    
    )
}